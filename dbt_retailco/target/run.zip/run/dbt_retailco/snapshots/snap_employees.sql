
      
  
    

  create  table "warehouse"."snapshots"."snap_employees"
  
  
    as
  
  (
    
    

    select *,
        md5(coalesce(cast(employee_id as varchar ), '')
         || '|' || coalesce(cast(updated_at as varchar ), '')
        ) as dbt_scd_id,
        updated_at as dbt_updated_at,
        updated_at as dbt_valid_from,
        
  
  coalesce(nullif(updated_at, updated_at), null)
  as dbt_valid_to
from (
        



select
    employee_id,
    updated_at,
    ingested_at,
    run_id,
    logical_date,
    source_employee_id,
    team_id,
    store_id,
    first_name,
    last_name,
    email,
    role,
    hired_date,
    created_at,
    source_updated_at,
    is_deleted
from "warehouse"."analytics"."stg_employees"

    ) sbq



  );
  
  