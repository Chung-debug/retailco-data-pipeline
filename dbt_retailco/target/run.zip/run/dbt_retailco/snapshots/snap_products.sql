
      
  
    

  create  table "warehouse"."snapshots"."snap_products"
  
  
    as
  
  (
    
    

    select *,
        md5(coalesce(cast(product_id as varchar ), '')
         || '|' || coalesce(cast(updated_at as varchar ), '')
        ) as dbt_scd_id,
        updated_at as dbt_updated_at,
        updated_at as dbt_valid_from,
        
  
  coalesce(nullif(updated_at, updated_at), null)
  as dbt_valid_to
from (
        



select
    product_id,
    updated_at,
    ingested_at,
    run_id,
    logical_date,
    source_product_id,
    team_id,
    sku,
    product_name,
    brand,
    category,
    sub_category,
    supplier,
    cost_price,
    selling_price,
    effective_from,
    created_at,
    source_updated_at,
    is_deleted
from "warehouse"."analytics"."stg_products"

    ) sbq



  );
  
  