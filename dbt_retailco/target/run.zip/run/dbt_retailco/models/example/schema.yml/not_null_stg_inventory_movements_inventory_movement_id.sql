
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    



select inventory_movement_id
from "warehouse"."analytics"."stg_inventory_movements"
where inventory_movement_id is null



  
  
      
    ) dbt_internal_test