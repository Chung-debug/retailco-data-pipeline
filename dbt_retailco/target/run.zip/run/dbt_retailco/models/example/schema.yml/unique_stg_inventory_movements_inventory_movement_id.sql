
    
    select
      count(*) as failures,
      count(*) != 0 as should_warn,
      count(*) != 0 as should_error
    from (
      
    
  
    
    

select
    inventory_movement_id as unique_field,
    count(*) as n_records

from "warehouse"."analytics"."stg_inventory_movements"
where inventory_movement_id is not null
group by inventory_movement_id
having count(*) > 1



  
  
      
    ) dbt_internal_test