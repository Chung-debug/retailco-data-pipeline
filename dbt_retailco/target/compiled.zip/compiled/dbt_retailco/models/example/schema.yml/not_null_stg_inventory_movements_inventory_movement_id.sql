
    
    



select inventory_movement_id
from "warehouse"."analytics"."stg_inventory_movements"
where inventory_movement_id is null


