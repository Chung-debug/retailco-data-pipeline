
    
    



select store_id
from "warehouse"."analytics"."stg_stores"
where store_id is null


