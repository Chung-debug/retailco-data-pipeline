
    
    



select order_id
from "warehouse"."analytics"."stg_orders"
where order_id is null


