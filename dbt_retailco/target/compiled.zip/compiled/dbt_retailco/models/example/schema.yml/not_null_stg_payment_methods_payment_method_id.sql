
    
    



select payment_method_id
from "warehouse"."analytics"."stg_payment_methods"
where payment_method_id is null


