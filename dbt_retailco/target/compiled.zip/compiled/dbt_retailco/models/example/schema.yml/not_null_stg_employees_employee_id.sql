
    
    



select employee_id
from "warehouse"."analytics"."stg_employees"
where employee_id is null


