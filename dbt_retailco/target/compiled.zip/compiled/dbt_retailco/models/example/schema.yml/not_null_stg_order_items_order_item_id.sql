
    
    



select order_item_id
from "warehouse"."analytics"."stg_order_items"
where order_item_id is null


