
    
    



select product_id
from "warehouse"."analytics"."stg_products"
where product_id is null


