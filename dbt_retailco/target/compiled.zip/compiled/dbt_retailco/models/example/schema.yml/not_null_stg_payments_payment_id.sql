
    
    



select payment_id
from "warehouse"."analytics"."stg_payments"
where payment_id is null


