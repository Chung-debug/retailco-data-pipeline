
    
    



select customer_id
from "warehouse"."analytics"."stg_customers"
where customer_id is null


