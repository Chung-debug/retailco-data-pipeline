
    
    



select payment_id
from "warehouse"."analytics"."fct_payments"
where payment_id is null


