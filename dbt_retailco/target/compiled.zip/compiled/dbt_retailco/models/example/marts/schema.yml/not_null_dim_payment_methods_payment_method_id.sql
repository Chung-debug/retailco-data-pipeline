
    
    



select payment_method_id
from "warehouse"."analytics"."dim_payment_methods"
where payment_method_id is null


