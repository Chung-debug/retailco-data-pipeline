
    
    



select customer_id
from "warehouse"."analytics"."dim_customers"
where customer_id is null


