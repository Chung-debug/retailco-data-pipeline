
    
    



select employee_id
from "warehouse"."analytics"."dim_employees"
where employee_id is null


