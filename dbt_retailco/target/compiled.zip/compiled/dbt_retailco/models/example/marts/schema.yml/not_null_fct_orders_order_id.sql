
    
    



select order_id
from "warehouse"."analytics"."fct_orders"
where order_id is null


