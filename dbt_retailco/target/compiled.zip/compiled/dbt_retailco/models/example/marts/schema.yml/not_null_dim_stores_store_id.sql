
    
    



select store_id
from "warehouse"."analytics"."dim_stores"
where store_id is null


