
    
    

with child as (
    select payment_method_id as from_field
    from "warehouse"."analytics"."fct_payments"
    where payment_method_id is not null
),

parent as (
    select payment_method_id as to_field
    from "warehouse"."analytics"."dim_payment_methods"
)

select
    from_field

from child
left join parent
    on child.from_field = parent.to_field

where parent.to_field is null


